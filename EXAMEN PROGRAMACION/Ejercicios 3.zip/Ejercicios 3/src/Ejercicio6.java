/*
6. -  Escribe un método que acepte dos argumentos: 
el carácter que se desea imprimir y el número de veces que se imprime 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio6 {
    public static void main ( String [] args ) {
    
        Scanner scan = new Scanner (System.in);
        char car;
        int num;
        
        do{
        System.out.println("Dime un caracter y cuantas veces lo quieres imprimir");
        car = scan.next().charAt(0);
        System.out.println("Cuantas veces quieres que se imprima");
        num = scan.nextInt();
        }while(num<0);
        
        caracterLineas(car,num);
        
        
    }
    
    public static void caracterLineas (char car, int num){
    
    for (int i = 1; i<=num; i++)
            System.out.print(car+" ");
    
    }
}

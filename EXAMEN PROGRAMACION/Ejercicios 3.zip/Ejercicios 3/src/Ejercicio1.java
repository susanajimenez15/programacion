/*
1. -  Escribe un método que devuelva la suma de dos 
enteros.
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio1 {
    public static void main ( String [] args){
    
    Scanner scan = new Scanner (System.in);
    int a,b,resultado;
    
    do{
        System.out.println("Dime dos valores enteros y te dire su suma:");
        a = scan.nextInt();
        b = scan.nextInt();
    }while(a<0 || b<0);
    
    resultado = sumaEnteros(a,b);
        
    System.out.println("La suma de los dos enteros es = "+resultado);
    
    }
    
    public static int sumaEnteros(int a, int b){
    
        int suma;
        suma = a + b;
        return suma;
    
    }
}


import java.util.Scanner;

/*
11. - Escríbase  un  método  que  dados  4  números  enteros  pasados  como 
parámetros, compruebe si dicha secuencia de números es capicúa. 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio11 {
    public static void main ( String [] args ){
        
        Scanner scan = new Scanner (System.in);
        String cadena;
        
        System.out.println("Dime la palabra que quieras que compruebe si es palindroma o no");
        cadena = scan.next();
        int i;
        int j;
        int longitud;
        int cont=0;
        longitud = (cadena.length());
        j = longitud - 1;
        
        for(i=0; i<=j; i++){
            
                if( cadena.charAt(i) == cadena.charAt(j)){
                    cont++;
                    j--;
                }
                else j--;
            
        }
         if(cont >= 1 && j<=2)
             System.out.println("La palabra SI es palindroma");
         if (cont == j/2)  
             System.out.println("La palabra SI es palindroma.");
         if (cont == 0 )
                System.out.println("La palabra NO es palindroma");
    
    
    
    }
}

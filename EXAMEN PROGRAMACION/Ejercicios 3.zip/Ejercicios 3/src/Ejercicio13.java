/*
 13. - Escribe un programa que solicite un número y visualizar en pantalla si es
o no un número perfecto.
Un número se considera perfecto cuando la suma de sus divisores,
excepto el mismo, es igual al propio número.
 */

/**
 *
 * @author victor
 */
import java.util.*;

public class Ejercicio13 {
    public static void main (String [] args ){
        
        Scanner scan = new Scanner (System.in);
        int num;
        
        do{
            System.out.println("Dime un numero y te dire si es perfecto:");
            num = scan.nextInt();
        }while (num <=0);
        
        numeroPerfecto(num);
            
            }
    public static void numeroPerfecto ( int num ){
    
        int suma = 0;
        
        for (int i = 1; i<num; i++)
            if (num%i == 0)
                suma+=i;
    
        if (suma == num)
            System.out.println("El numero introducido SI es un numero perfecto");
        else
            System.out.println("El numero introducido NO es un numero perfecto");
    }
    
    
}

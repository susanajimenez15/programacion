/*
7. -  Escribe un método que acepte tres argumentos: 
un carácter y dos enteros.  
El  carácter  se  debe  imprimir.  El  primer  entero  indi¡ca  el  número  de  veces 
que  se  imprimirá  el  carácter  en  la  línea  y  el  
segundo  entero  indica  el número de líneas que deben imprimirse. 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio7 {
    public static void main ( String [] args ) {
    
        Scanner scan = new Scanner (System.in);
        int num,lineas;
        char car;
        do{
            System.out.println("Dime el caracter que deseas imprimir");
            car = scan.next().charAt(0);
            System.out.println("Dime la cantidad de veces que quieres que se imprima");
            num = scan.nextInt();
            System.out.println("Dime cuantas lineas quieres que salgan");
            lineas = scan.nextInt();
        }while(num<0);
        
        metodoLineas(car,num,lineas);
    }

    public static void metodoLineas(char car, int num, int lineas){
        
        for (int i = 1; i<=lineas ; i++){
            for(int x=1; x<=num; x++)
                System.out.print(car);
                System.out.println("");
        }
        
    
    }

}

    


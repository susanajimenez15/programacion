/*
8. -  Escribe una método que acepte dos argumentos: 
el carácter que se desea 
imprimir y el número de líneas que se imprimen en forma triangular 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio8 {
    public static void main ( String [] args ){
    
    
        Scanner scan = new Scanner (System.in);
        char car;
        int num;
        
        do{
            System.out.println("Dime un caracter y cuantas veces lo quieres imprimir en forma de piramide");
            car = scan.next().charAt(0);
            System.out.println("Cuantas lineas quieres que se imprima");
            num = scan.nextInt();
        }while(num<0);
        
        metodoPiramide(car,num);
    
    }
    
    public static void metodoPiramide(char car, int num){
    
        int i,y;
        
        for ( i =0; i<=num; i++){
            for (int x = 0; x<= num-i; x++)
                System.out.print(" ");
            for(y=0; y<i*2-1; y++)
                System.out.print(car);
            System.out.println();
        }    
    }
    
}


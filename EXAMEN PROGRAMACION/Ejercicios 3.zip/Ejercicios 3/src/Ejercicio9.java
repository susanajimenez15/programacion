/*
9. -  Se  llama  media  armónica  de  dos  números  el  resultado  obtenido al 
calcular los inversos de los números, calcular la media y calcular el inverso 
del  resultado.  Escribe  un  método  que  acepte    dos  argumentos  double  y
devuelva la media armónica de los números. 
 */

/**
 *
 * @author mati
 */

public class Ejercicio9 {
    public static void main ( String [] args){
    
        
       
    
    
    }
}

/*
10. - Escribe un método que acepte un entero y calcule su factorial n! 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio10 {
    public static void main ( String [] args ){
    
        Scanner scan = new Scanner (System.in);
        int num;
        
        do{
        System.out.println("Dime un numero para calcular su factorial");
        num = scan.nextInt();
        }while(num<0);
        
        System.out.println(""+factorial(num));
    }
    
    public static int factorial (int num){
    
        int producto=1;
       
        for(int i = 1; i<=num; i++)
            producto*=i;
    
        return producto;
    }
}

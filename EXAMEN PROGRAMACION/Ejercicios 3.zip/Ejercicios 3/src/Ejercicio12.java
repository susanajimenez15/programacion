/*
 Escribe  un  programa  en  Java  que,  dado  el  nombre  de  una  persona  y  el 
idioma de preferencia de esa persona, escriba en pantalla un saludo a esa 
persona en el idioma elegido, con el estilo: ”Buenos días Pepe Sánchez”. 
 Los idiomas disponibles serán 
(a) Valenciano  
(b) Castellano  
(c) Ingles
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio12 {
    public static void main ( String [] args ){
    
        String nom;
        int op;
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Dime tu nombre ");
        nom = scan.nextLine();
        System.out.println("------------------------------------");
        System.out.println("Elige la opcion que te interese;");
        System.out.println("1. Valenciano");
        System.out.println("2. Castellano");
        System.out.println("3. Ingles");
        op = scan.nextInt();
        
        opciones(nom,op);
        
        }
       public static void opciones( String nom, int op){
    
           switch( op ) {
            case 1:
                System.out.println("Bon dia "+nom);
            break;
      
            case 2:
                System.out.println("Buenos dias "+nom);
            break;
        
            case 3:
                 System.out.println("Good morning "+nom);
            break;
                
            default:
                System.out.println("No has introducido ninguna opcion de las ofertadas.");
      
            break;
        }   
    }
}   
   
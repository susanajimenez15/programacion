/*
 5. -  Diseña  un  método  que  devuelva  el  mayor  de  cuatro  números  que  
se  le pasan como argumentos. 
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio5 {
    public static void main (String [] args){
    
        int [] v = new int[4];
        int mayor,i;
        Scanner scan = new Scanner (System.in);
        
        System.out.println("Dime 4 valores y te dire el mayor");
        for(i = 0; i<4; i++){
        v[i]=scan.nextInt();
        }
                
        mayor = mayor(v);
        
        System.out.println("El mayor de los numeros introducidos es " +mayor);
    }
    
    public static int mayor (int [] v ){
    
        int i;
        int mayor = v[0];
        
        for( i=0; i<v.length;i++){
            mayor=v[0];
            if(mayor < v[i])
                mayor = v[i];
        }
        return mayor;
    }
}

/*
 4. -  Escribe un método que devuelva el mayor de  tres números 
 */

/**
 *
 * @author mati
 */
import java.util.Scanner;

public class Ejercicio4 {
    public static void main ( String [] args ) {
    
    Scanner scan = new Scanner (System.in);
    double a,b,c;
    double mayor;
    
    do{
    System.out.println("Dame tres valores y te dire el mayor");
    a = scan.nextDouble();
    b = scan.nextDouble();
    c = scan.nextDouble();
    }while (a<0 || b<0 || c<0);
    
    mayor = mayor(a,b,c);
    
    System.out.println("El mayor de los numeros introducidos es " +mayor);
   
    }
    
     public static double mayor(double a, double b, double c){
    
        double mayor=0;
        
        if(a>=b){
           if(a>c)
               mayor = a;
        }
        if(b>=a){
            if(b>c)
                mayor = b;
        }
        if(c>=a){
            if(c>b)
                mayor = c;
        }
        return mayor;
    
    }
}

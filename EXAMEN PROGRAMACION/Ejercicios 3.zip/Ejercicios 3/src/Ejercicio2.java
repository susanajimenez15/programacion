/*
2. - Escribe un programa que calcule el área y la longitud de una
circunferencia en función del radio (leído desde teclado). Se ha de escribir
un método para calcular el área y otro para la longitud. Las fórmulas del
área y la longitud de una circunferencia: A=pi * r2 y L=2*i * r


 */

/**
 *
 * @author victor
 */
import java.util.*;

public class Ejercicio2 {
    public static void main ( String [] args){
    
        Scanner scan = new Scanner (System.in);
        double radio,area,longitud;
        
        do{   
        System.out.println("Dime el radio de una circunferencia y te dire su area y longitud.");
        radio = scan.nextDouble();  
        }while(radio<0);
    
        area = Area(radio);
        longitud = Longitud(radio);
        
        System.out.println("El area de la circunferencia es de "+area+" m2.");
        System.out.println("La longitud de la circunferencia es de "+longitud+" m.");
   
    }
    
    public static double Area (double radio){
    
        double area;
        double PI = Math.PI;
    
        area = 2*PI*radio*radio;
    
        return area;
    
    }
    public static double Longitud (double radio){
    
        double longitud;
        double PI = Math.PI;
    
        longitud = 2*PI*radio;
        
        return longitud;
    
    }
}

/*
3. -  Escribe un método que devuelva el mayor de dos números.
 */

/**
 *
 * @author mati
 */
import java.util.*;

public class Ejercicio3 {
    public static void main ( String [] args ) {
    
    Scanner scan = new Scanner (System.in);
    double a,b;
    double mayor;
    
    do{
    System.out.println("Dame dos valores y te dire el mayor");
    a = scan.nextDouble();
    b = scan.nextDouble();
    }while (a<0 || b<0);
    
    mayor = mayor(a,b);
    
    System.out.println("El mayor de los numeros introducidos es " +mayor);
    
    }
    
    public static double mayor(double a, double b){
    
        double mayor;
        
        if(a>b)
            mayor = a;
        else
            mayor = b;
        
        return mayor;
    
    }
}

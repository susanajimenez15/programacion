
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author suus
 */
import java.util.Scanner;

public class ejercicio3 {
    public static void main(String[] args) {
        
        int [] vector = new int [20];
        Scanner scan = new Scanner (System.in);
        
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
        System.out.println("----------------------------");
        System.out.println("Visualizacion de 4 en 4:");
        for(int i=0; i<vector.length; i++){
            if(i%4 == 0)
                System.out.println("\n");
            System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        
    }
}



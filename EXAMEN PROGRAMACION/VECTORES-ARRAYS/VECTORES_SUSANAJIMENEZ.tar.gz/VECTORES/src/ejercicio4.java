/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author suus
 */
import java.util.Scanner;

public class ejercicio4 {
    public static void main(String[] args) {
        
        int [] vector = new int [10];
        Scanner scan = new Scanner (System.in);
        
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
        System.out.println("-----------------------------------------");
        System.out.println("Visualizacion del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        System.out.println("-----------------------------------------");
        System.out.println("Visualizacion de las posiciones cuyo contenido es par:");
        for(int i=0; i<vector.length; i++){
            if (vector[i]%2 == 0)
                System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        System.out.println("-----------------------------------------");
        System.out.println("Visualizacion de las posiciones cuyo contenido es impar:");
        for(int i=0; i<vector.length; i++){
            if (vector[i]%2 != 0)
                System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        
        
    }
}
  



import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author suus
 */
public class ejercicio9 {
     public static void main(String[] args) {
        
        int [] vector = new int [20];
        Scanner scan = new Scanner (System.in);
        int mayor = vector[0];
        
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
        System.out.println("Visualizar los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"] = "+vector[i]);
            if(mayor<vector[i])
                mayor=vector[i];
        }
        for(int i=0; i<vector.length; i++){
            if(mayor==vector[i]){
                System.out.println("La posiciond el elemento mayor del vector: Posicion ["+i+" ] = "+vector[i]);
            }
            break;
            }
     }
}

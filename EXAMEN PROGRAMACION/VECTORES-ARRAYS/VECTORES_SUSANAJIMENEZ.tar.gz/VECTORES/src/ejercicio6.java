/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author suus
 */
public class ejercicio6 {
    public static void main(String[] args) {
        
        int [] vector = new int [10];
        Scanner scan = new Scanner (System.in);
        int suma = 0;
        
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
        System.out.println("-----------------------------------------");
        System.out.println("Visualizacion del contenido del vector");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        System.out.println("-----------------------------------------");
        System.out.println("Elementos pares cuyo contenido es par:");
        
        for(int i=0; i<vector.length; i++){
            if (i%2==0 && vector[i]%2==0)
                System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        System.out.println("-----------------------------------------");
        System.out.println("Elementos impares cuyo contenido es impar:");
        
        for(int i=0; i<vector.length; i++){
            if (i%2!=0 && vector[i]%2!=0)
                System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        
        
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author suus
 */
public class ejercicio5 {
    public static void main(String[] args) {
        
        int [] vector = new int [50];
        Scanner scan = new Scanner (System.in);
        int suma = 0;
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }

        for(int i=0; i<vector.length; i++){
            if(vector[i]%2 == 0)
                suma+=vector[i];
        }
        System.out.println("-----------------------------------------");
        System.out.println("La suma de los elementos pares contenidos en el vector es "+suma);
    }
}
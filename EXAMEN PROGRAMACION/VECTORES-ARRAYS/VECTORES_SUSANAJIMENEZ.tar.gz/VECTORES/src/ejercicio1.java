/*
1.Escribe un programa que permita introducir los valores de
un vector de diez elementos numéricos y luego imprimirlos.
 */

/**
 *
 * @author suus
 */
import java.util.*;
public class ejercicio1 {
    public static void main(String[] args) {
        
        int [] vector = new int [10];
        Scanner scan = new Scanner (System.in);
        
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
         
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"] = "+vector[i]);
        }
        
    }
}

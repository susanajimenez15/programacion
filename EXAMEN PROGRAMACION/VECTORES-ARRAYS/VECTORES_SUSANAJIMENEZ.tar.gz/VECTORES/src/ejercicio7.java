
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author suus
 */
public class ejercicio7 {
    public static void main(String[] args) {
        
        int [] vector = new int [50];
        Scanner scan = new Scanner (System.in);
        int contador = 0;
        
        System.out.println("Introduce los elementos del vector:");
        for(int i=0; i<vector.length; i++){
            System.out.println("Posicion ["+i+"]");
            vector[i]=scan.nextInt();
        }
        for (int i=0; i<vector.length; i++)
                if(vector[i]==0){
                    System.out.println("El primer elemento del vector cuyo contenido es cero es la poscion["+i+"] = "+vector[i]);
                    contador++;
                    break;
                }
        if( contador >= 0)
            System.out.println("No hay ningún elemento del vector cuyo contenido sea 0.");
    }
        
}

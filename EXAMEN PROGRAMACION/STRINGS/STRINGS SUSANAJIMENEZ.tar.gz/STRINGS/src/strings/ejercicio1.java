/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;
import java.util.*;
/**
 *
 * @author mati
 */
public class ejercicio1 {
    public static void main(String[] args) {
        
        Scanner scan = new Scanner (System.in);
        
        String nombre = new String ();
        String apellido1 = new String ();
        String apellido2 = new String ();
                
        System.out.println("Dime tu nombre");
        nombre = scan.nextLine();
        System.out.println("Dime tu primer apellido");
        apellido1 = scan.nextLine();
        System.out.println("Dime tu segundo apellido");
        apellido2 = scan.nextLine();
        String espacio = " ";
        
        
        String nombreCompleto = nombre+espacio+apellido1+espacio+apellido2;
        
        System.out.println("El nombre completo "+nombreCompleto);
        System.out.println("En mayusculas: "+(nombreCompleto.toUpperCase()));
        System.out.println("En minúsculas: "+(nombreCompleto.toLowerCase()));
        int longitud = nombreCompleto.length();
        System.out.println("La longitud de tu nombre es de "+longitud+" carácteres.");
        System.out.println("Los dos primeros carácteres de la cadena: "+nombreCompleto.substring(0, 2));
        System.out.println("Los dos ultimos carácteres de la cadena: "+nombreCompleto.substring(nombreCompleto.length()-2, nombreCompleto.length()));
        
        int contador = 0;
        String x = new String();
        for (int i = 0; i<nombreCompleto.length(); i++){
            if (nombreCompleto.charAt(i) == nombreCompleto.charAt(nombreCompleto.length()-1))
                contador++;
            }
        
        System.out.println("El numero de veces que se repite el ultimo caracter de la cadena es: "+contador);
                
        char primer = nombreCompleto.charAt(0);
        char primerMay=Character.toUpperCase(primer);
        nombreCompleto.replaceAll(x, espacio);
        System.out.println(""+nombreCompleto);
        
        String asteriscos="***";
        System.out.println(""+asteriscos+nombreCompleto+asteriscos);
        int posicion = longitud-1;
        
        String nombreInvertido=new String();
        
        for (int i = nombreCompleto.length()-1; i >=0 ; i--){
		nombreInvertido += nombreCompleto.charAt(i);
                
        }
        System.out.println("La cadena invertida "+nombreCompleto+ " es "+nombreInvertido);
    }
}

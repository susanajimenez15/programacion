/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;
import java.util.*;
/**
 *
 * @author mati
 */
public class ejercicio5 {
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        String cadena = new String();
        String letra = new String();
        System.out.println("Dime la cadena de texto");
        cadena = scan.nextLine();
        System.out.println("Dime el caracter y te dire cuantas veces se repite");
        letra = scan.next();
        System.out.println("Las veces que se repite "+letra+" son "+contarChars(cadena,letra));
    }
    public static int contarChars(String cadena, String letra){
    
        int contador=0;
        for (int i=0; i < cadena.length(); i++){
            if (cadena.charAt(i)== letra.charAt(0))
                contador++;
        }
        return contador;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;

/**
 *
 * @author mati
 */
public class ejercicio4 {
    public static void main(String[] args) {
    
        String cadena = new String();
        cadena = "esto1234es5678bueno900";
        System.out.println(""+cambiarSilabas(cadena));
        System.out.println(""+cambiarNumeros(cadena));
               
       
    }
    public static String cambiarSilabas (String cadena){
     
        String cadenaNueva = cadena.replaceAll("es", "no por");
    
             return cadenaNueva;
    }
    public static String cambiarNumeros (String cadena){
     
        String cadenaNueva;
        cadenaNueva = cadena.replaceAll("\\d+", "*");
    
             return cadenaNueva;
    }
}

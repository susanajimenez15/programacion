/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;

/**
 *
 * @author mati
 */
public class ejercicio3 {
    public static void main(String[] args) {
        
    String cadena1 = "Hola que tal";
    String cadena2 = "Adios";
        System.out.println(""+mitadCadena(cadena1));
        System.out.println(""+mitadCadena(cadena2));
    }
    
    public static String mitadCadena ( String cadena ){
        
        int longitud = cadena.length()-1;
        int longitudMitad=(int) longitud/2;
        String mitadCadena = new String();
        for(int i = 0; i <=longitudMitad; i++){
            mitadCadena = mitadCadena + cadena.charAt(i);
        }
            
            return mitadCadena;
    }

}